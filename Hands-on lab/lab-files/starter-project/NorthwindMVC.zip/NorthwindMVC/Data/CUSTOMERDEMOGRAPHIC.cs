﻿using System;
using System.Collections.Generic;

#nullable disable

namespace NorthwindMVC.Data
{
    public partial class Customerdemographic
    {
        public string Customertypeid { get; set; }
        public string Customerdesc { get; set; }
    }
}
